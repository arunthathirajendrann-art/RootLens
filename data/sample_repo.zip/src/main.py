def create_connection_pool(size=2):
    print(f"Pool created with size: {size}")
    return {"status": "ok"}
